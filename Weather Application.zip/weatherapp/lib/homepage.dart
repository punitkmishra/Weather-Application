import 'package:flutter/material.dart';
import 'package:weatherapp/networking.dart';
import 'package:weatherapp/weatherdetails.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  void initState() {
    
    getweatherdata();
    // TODO: implement initState
    super.initState();
  }

  void getweatherdata()async{
    Network network = Network();
    await network.getLocation();
    Navigator.of(context).push(MaterialPageRoute(builder: (context) => Details(cityname: network.cityname,humidity: network.humidity,pressure: network.pressure,temp: network.temp,visibility: network.visibility,)));
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('climate app')),
      body: Center(
        child: CircularProgressIndicator(),
      )
      
    );
  }
}
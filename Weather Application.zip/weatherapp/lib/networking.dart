import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';

class Network{
  final String baseurl = "https://api.openweathermap.org/data/2.5/weather";
  final String key = "7345bde8401030bce2b8a5af06dda52f";
  late String lat;
  late String long;


  String humidity ="";
  String visibility = "";
  String pressure = "";
  String temp = "";
  String cityname="";
  String des="";


  Future <void> getData() async {
   
    var url = Uri.parse("$baseurl?lat=$lat&lon=$long&appid=$key");
    var response = await http.get(url);
    var jsondata = jsonDecode(response.body);
    // print(jsondata);
    print(response.body);
    visibility =  jsondata["visibility"].toString();
    humidity =  jsondata["main"]['humidity'].toString();
    pressure =  jsondata["main"]['pressure'].toString();
    temp = (jsondata["main"]["temp"]).toStringAsFixed(1);
    cityname =  jsondata["name"].toString();
    print(visibility);
    print(humidity);
    print(pressure);
    print(temp);
    print(cityname);

  }

  Future<void> getLocation()async {
    Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.low);
    lat = position.latitude.toString();
    long = position.longitude.toString();
   
     await getData();
  }

}